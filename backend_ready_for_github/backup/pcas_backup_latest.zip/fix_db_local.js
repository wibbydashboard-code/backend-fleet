
import mysql from 'mysql2/promise';
import fs from 'fs';
import dotenv from 'dotenv';

// Cargar variables de entorno
dotenv.config();

const dbConfig = {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT) : 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: (process.env.DB_HOST && process.env.DB_HOST !== 'localhost') ? { rejectUnauthorized: false } : false
};

async function fixDb() {
    console.log('Connecting to TiDB...');
    console.log(`Host: ${dbConfig.host}`);

    let conn;
    try {
        conn = await mysql.createConnection(dbConfig);
        console.log('Connected!');

        // 1. Agregar columna status a companies
        try {
            console.log('Adding status column to companies...');
            await conn.execute("ALTER TABLE companies ADD COLUMN status VARCHAR(50) DEFAULT 'Activo'");
            console.log("✅ Added status column");
        } catch (e) {
            console.log("⚠️ Status column likely exists or error:", e.message);
        }

        // 2. Agregar columna rfc a providers (por si acaso falta, aunque en el esquema del usuario parece que no)
        // El usuario dijo que companies no tiene status. Arreglamos eso.

        console.log('Database fix complete.');
    } catch (err) {
        console.error('❌ Connection failed:', err);
    } finally {
        if (conn) await conn.end();
    }
}

fixDb();
